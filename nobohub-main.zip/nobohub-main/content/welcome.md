title: Welcome to My Blog
date: 2023-07-20
description: Welcome to my personal blog where I share thoughts and insights.

# Welcome to My Blog

This is the first post on my personal blog. Here I'll be sharing various thoughts, insights, and knowledge about different topics.

## Features of This Blog

1. Markdown Support
2. Mathematical Equations
3. Table of Contents
4. Code Highlighting

### Example Math Equation

Here's an example of a mathematical equation using MathJax:

$$
E = mc^2
$$

### Code Example

